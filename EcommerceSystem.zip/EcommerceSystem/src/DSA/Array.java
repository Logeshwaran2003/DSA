package DSA;
/*List implementation using array
Dynamic array-implement array based on dynamically not fixed static
 */

import java.util.*;

class DynamicArray{
    private static int initCapacity=16;
    private int a[];
    private int size;
    private int capacity;

    public DynamicArray(){
        this.a=new int[initCapacity];
        this.size=0;
        this.capacity=initCapacity;

    }

    public void add(int data){
        if (size==capacity){
            expandArray();//doubling the array size because it is dynamic array
        }
        a[size++]=data;

    }

    private void expandArray(){
        capacity*=2;
        a=Arrays.copyOf(a,capacity);//copy the array a valut to another array with newly added capacity
    }

    public void display(){
        for(int i=0;i<size;i++){
            System.out.print(a[i]+" ");
        }
        System.out.println();
    }

    public void insertData(int pos,int value){
        if (size==capacity){
            expandArray();}
       for (int i=size-1;i>=pos;i--) {//Adding data in specific position we need to shift the data
           a[i + 1] = a[i];
       }
       a[pos]=value;
       size++;
        System.out.println("Data inserted successfully");
    }

    public void deleteData(int Pos){
        if (size==0){
            System.out.println("List is empty");
        }
        for (int i=Pos+1;i<size;i++){//removing data in specific position we need shift the data
            a[i-1]=a[i];
        }
        size--;
        if (capacity>initCapacity && capacity>size*3){
            shringcapacity();//reduce the capacity because of unwanted space allocation
        }
        System.out.println("Data deleted successfully");
    }

    private void shringcapacity(){
        capacity/=2;
        a=Arrays.copyOf(a,capacity);
    }

    public int getData(int pos){
        return a[pos];
    }

    public void updateData(int pos,int val){
        a[pos]=val;
    }

    public String search(int val){
        for (int i=0;i<size;i++){
            if (a[i]==val){
                return "Index of "+val+" is "+i;
            }
        }
        return "Data not found";
    }

    public void clear(){
        size=0;
    }

    public boolean contains(int val){
        for (int i=0;i<size;i++){
            if (a[i]==val){
                return true;
            }
        }
        return false;
    }

    public int getSize(){
        return size;
    }

}
public class Array {
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        DynamicArray arr=new DynamicArray();
        int data;
        while (true){
        System.out.println("----------List Menu------------");
        System.out.println("1.Insert at end");
        System.out.println("2.Display the list");
        System.out.println("3.Insert at specific position");
        System.out.println("4.Delete at specific position");
        System.out.println("5.Delete at end");
        System.out.println("6.Delete from beginning");
        System.out.println("7.Insert at beginning");
        System.out.println("8.Get value based on index");
        System.out.println("9.Update the data");
        System.out.println("10.Search the data it return index");
        System.out.println("11.Clear");
        System.out.println("12.Contains the data or not");
        System.out.println("13.Exit");
        System.out.println("----------------------------------");
        System.out.print("Choose the option:");
        int choose= scan.nextInt();
        switch (choose){
            case 1:
                System.out.println("Adding data at end:");
                System.out.print("Enter the data to add:");
                int val= scan.nextInt();
                arr.add(val);
                break;
            case 2:
                System.out.println("Display the list");
                arr.display();
                break;
            case 3:
                System.out.println("Inserting at specific position");
                System.out.print("Enter the position:");
                int pos= scan.nextInt();
                System.out.print("Enter the data:");
                int value= scan.nextInt();
                arr.insertData(pos,value);
                break;
            case 4:
                System.out.println("Deleting at specific position");
                System.out.print("Enter the position:");
                int Pos= scan.nextInt();
                arr.deleteData(Pos);
                break;
            case 5:
                System.out.println("Deleting at end");
                int d= arr.getSize()-1;
                arr.deleteData(d);
                break;
            case 6:
                System.out.println("Delete at beginning");
                arr.deleteData(0);
                break;
            case 7:
                System.out.println("Insert data at beginning");
                System.out.print("Enter the data:");
                int v=scan.nextInt();
                arr.insertData(0,v);
                break;
            case 8:
                System.out.println("Fetching data bsed on index");
                System.out.print("Enter the index:");
                int index= scan.nextInt();
                System.out.println(arr.getData(index));
                break;
            case 9:
                System.out.println("Update the data");
                System.out.print("Enter the position:");
                int in= scan.nextInt();
                System.out.print("Enter the data:");
                int Value= scan.nextInt();
                arr.updateData(in,Value);
                break;
            case 10:
                System.out.println("Searching");
                System.out.print("Enter the data:");
                int Valu=scan.nextInt();
                System.out.println(arr.search(Valu));
                break;
            case 11:
                System.out.println("Clearing");
                arr.clear();
                break;
            case 12:
                System.out.println("Contains or not");
                System.out.print("Enter the data:");
                int Va=scan.nextInt();
                System.out.println(arr.contains(Va));
                break;
            case 13:
                System.out.println("Exiting...........");
                System.exit(0);
                break;
            default:
                System.out.println("Invalid option");
        }

    }
    }
}