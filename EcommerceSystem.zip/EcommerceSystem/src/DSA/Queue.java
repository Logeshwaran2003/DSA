package DSA;

/*Queue-FIFO
use-printers,cpu scheduling,routers

enqueue
dequeue
front
rear

two methods-1.if dequeue, return arr[0] and shift all data one step back. O(n)
            2.if dequeue, return arr[front] and increment front. O(1)

*/





public class Queue{
    int front;
    int rear;
    int a[];
    public Queue(){
        front=0;
        rear=-1;
        a=new int[10];
    }

    public void enqueue(int data){
        a[++rear]=data;
    }

    // public void dequeue(){
    //     System.out.println(a[front]);
    //     for (int i=front+1;i<=rear;i++){
    //         a[i-1]=a[i];
    //     }
    //     --rear;
    // }

    public void dequeue(){
        System.out.println(a[front++]);

    }

    public void display(){
        for (int i=front;i<=rear;i++){
            System.out.print(a[i]+" ");
        }
        System.out.println();
    }

    public static void main(String args[]){
        Queue q1=new Queue();
        q1.enqueue(1);
        q1.enqueue(2);
        q1.enqueue(3);
        q1.display();
        q1.dequeue();
        q1.dequeue();
        q1.dequeue();



    }
}
