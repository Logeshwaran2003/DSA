package DSA;

/* Binary Search Tree

It like a binary tree have 0,1,2 child nodes

Parent node have small item in left side and large item in right side

Searching is easy because left have small elements and right have large elements

Search,insert,delete have complexity of n(h), h-height
If balanced tree maintained means complexity is o(log n)


 */

public class BinarySearchTree {
    Node root;

    class Node {
        int data;
        Node left, right;

        Node(int data) {
            this.data = data;
            left = null;
            right = null;
        }
    }
    public BinarySearchTree(int data){
        root=new Node(data);
    }
    public Node insertData(Node root,int data){
        if (root==null){
            return new Node(data);
        }
        if (data<root.data){
            root.left=insertData(root.left,data);
        }
        else{
            root.right=insertData(root.right,data);
        }
        return root;
    }

    public Node search(Node root,int data){
        if (root==null || root.data==data){
            return root;
        }

        if (data<root.data){
            return search(root.left,data);
        }
        return search(root.right,data);
    }

    public void inOrderTraverse(Node root) {
        if (root != null) {
            inOrderTraverse(root.left);
            System.out.print(root.data + " ");
            inOrderTraverse(root.right);
        }
    }

    public static void main(String args[]){
        BinarySearchTree bst=new BinarySearchTree(50);
        bst.insertData(bst.root,20);
        bst.insertData(bst.root,70);
        bst.inOrderTraverse(bst.root);
        if (bst.search(bst.root,70)==null){
            System.out.println();
            System.out.println("Not found");
        }
        else{
            System.out.println();
            System.out.println("Found");
        }
    }


}
