package DSA;

/*
All trees are graph but all graph are not trees
Traversing types - BFS and DFS

1.BFS:select node ---> explore completely(Queue implementation)
Algorithm:
queue=[],visited=[]
add start vertex to Queue
mark start as visited
while Queue is not empty:
        v=dequeue from queue
        for each(adj vertex av:v)
        if av is not visited:
        add av to Queue
        mark as visted

Application:
Path finding
Shortest distance
GPS-finding nearby location

DFS -Keep digging (Stack and recursion implementation)-It will go with vertex--child vertex---child vertex.child vertex
Algorithm:
DFS(v)
mark v as visited
for each(adj vertex av:v)
    if av is not visited:
         DFS(av)

Application:
Maze puzzles
topology sorting
path finding

*/

import java.util.*;
import java.util.LinkedList;
import java.util.Queue;

public class GraphTraverse {
    ArrayList<ArrayList<Integer>> adjlist=new ArrayList<>();

    public GraphTraverse(int size){
        for (int i=0;i<size;i++){
            adjlist.add(new ArrayList<Integer>());
        }
    }

    public void addEdge(int v,int e){
        adjlist.get(v).add(e);
        adjlist.get(e).add(v);
    }

    public void displayList(){
        for (int i=0;i<adjlist.size();i++){//i is vertex number
            System.out.println("Vertex number is "+i);
            for (int j=0;j<adjlist.get(i).size();j++){
                System.out.print(adjlist.get(i).get(j)+" ");

            }
            System.out.println();

        }
    }

    public void bfs(int v) {// v is starting vertex
        int size = adjlist.size();//total number of vertex
        Queue<Integer> queue = new LinkedList<>();
        boolean[] visited = new boolean[size];
        visited[v] = true;
        queue.add(v);
        while (queue.size() != 0) {
            int vertex = queue.remove();
            System.out.print(vertex + " ");
            for (int i = 0; i < adjlist.get(vertex).size(); i++) {
                int av = adjlist.get(vertex).get(i);
                if (!visited[av]) {
                    queue.add(av);
                    visited[av] = true;
                }
            }
        }
    }

    public void dfs(int v){
        int size = adjlist.size();//total number of vertex
        boolean[] visited = new boolean[size];
        dfs2(v,visited);

    }

    public void dfs2(int v,boolean visited[]) {//Why created this because in main we call dfs(0) only so create a another function and call from that function.Here dfs call the dfs2.we need value and visited arr
        visited[v]=true;
        System.out.print(v+" ");
        for (int i=0;i<adjlist.get(v).size();i++){
             int av=adjlist.get(v).get(i);
             if (!visited[av]) {
                 dfs2(av,visited);
             }
        }
    }

    public static void main(String args[]){
        GraphTraverse g=new GraphTraverse(5);
        g.addEdge(0,1);
        g.addEdge(0,4);
        g.addEdge(1,2);
        g.addEdge(1,4);
        g.addEdge(2,3);
        g.addEdge(3,4);
        g.displayList();
        System.out.println("BFS");
        g.bfs(0);
        System.out.println();
        System.out.println("DFS");
        g.dfs(0);


    }
}
