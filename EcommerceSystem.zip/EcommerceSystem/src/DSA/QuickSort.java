package DSA;

import java.util.Arrays;

public class QuickSort {

    public void sort(int arr[],int low,int high){
        if (low>=high){
            return;
        }
        int start=low;
        int end=high;
        int mid=(start+end)/2;
        int pivot=arr[mid];
        while (start<=end){
            while(arr[start]<pivot){
                start++;
            }
            while(arr[end]>pivot){
                end--;
            }
            if(start<=end){
                int temp=arr[start];
                arr[start]=arr[end];
                arr[end]=temp;
                start++;
                end--;
            }

        }
        sort(arr,start,high);
        sort(arr,low,end);
    }
    public static void main(String args[]){
        QuickSort sorting=new QuickSort();
        int arr[]={3,1,34,20,10};
        sorting.sort(arr,0, arr.length-1);
        System.out.println(Arrays.toString(arr));
    }
}
