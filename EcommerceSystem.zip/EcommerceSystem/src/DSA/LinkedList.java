package DSA;

/* LinkedList

why we using linkedlist rather than array?

Linked list is dynamic,flexible but array is static ,it requires fixed size and it is contigious.Linked list is
contagious it contains nodes ,that node contains data and pointer.Pointer is used to point the next node.

first node - Head
last node - Tail
last node pointer will be always null

steps:
define the node(class)
Always head node pointer will be null when empty

1.Insert at beginning:O(1)
Create
assign data and pointer values

2.Traverse:O(n)
get first node using head
get next node by current node pointer until pointer is null

3.Read element/Update element:O(n)
get first node by using head
get next node by current node pointer until position times

4.Insert at Position:O(n)
get first node by using head
get next node by current node pointer until position-1 times
reassigning the pointer

5.Delete at position:O(n)
get first node by using head
get next node by current node pointer until position times keep track on previous node
reassigning the pointer
free the memory

6.Is the list empty?
if the head pointer is null,list is empty,If not it conatins atleast one element


*/

import java.util.*;
public class LinkedList
{
    Node head;

    class Node{
        int data;
        Node next;
        Node(int val){
            data=val;
            next=null;
        }
    }

    public LinkedList(){
        head=null;//It represents the list is empty initially

    }

    public void insertDataAtBeginning(int data){
        Node newNode=new Node(data);
        if (head==null){//List is empty
            head=newNode;
        }
        else{//List is not empty
            newNode.next=head;
            head=newNode;
        }
    }
    public void display(){
        Node temp=head;
        while (temp!=null){
            System.out.print(temp.data+" ");
            temp=temp.next;//traverse until null
        }
        System.out.println();
    }

    public void insertDataAtSpecificIndex(int pos,int val){
        if (pos==0){
            insertDataAtBeginning(val);
            return;
        }
        Node newNode=new Node(val);
        Node temp=head;
        for (int i=1;i<pos;i++){//jump to prev node
            temp=temp.next;
            if (temp==null){
                System.out.println("Invalid option");
            }
        }
        newNode.next=temp.next;
        temp.next=newNode;

    }

    public void deleteAtPosition(int pos){
        if (head==null){
            System.out.println("List is empty");
        }
        else if (pos==0){
            deleteAtBeginning();
            return;
        }
        Node temp=head;
        Node prev=null;//for pointing the next element
        for (int i=1;i<pos;i++){//jump to the position which is entered
            prev=temp;//keep track prev node
            temp=temp.next;

        }
        prev.next=temp.next;
    }

    public void reverse(){
        Node prev=null;
        Node current=head;
        Node next=head.next;
        while(current!=null){
            next=current.next;
            current.next=prev;
            prev=current;
            current=next;
        }
        head=prev;
    }

    public void deleteAtBeginning(){
        head=head.next;
    }

    public int search(int data){
        Node temp=head;
        int i=0;
        while (temp!=null){
            if (temp.data==data){
                return i;
            }
            temp=temp.next;
            i++;
        }
        return -1;
    }


    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        LinkedList list=new LinkedList();
        while (true){
            System.out.println("1.InsertDataAtBeginning");
            System.out.println("2.Display");
            System.out.println("3.Insert at position");
            System.out.println("4.Delete at position");
            System.out.println("5.Reverse the list");
            System.out.println("6.Search data");
            System.out.print("Choose the option:");
            int choose=scan.nextInt();
            switch (choose){
                case 1:
                    System.out.print("Enter the data:");
                    int data=scan.nextInt();
                    list.insertDataAtBeginning(data);
                    break;
                case 2:
                    System.out.println("Display");
                    list.display();
                    break;
                case 3:
                    System.out.println("3.Insert at position");
                    System.out.print("Enter the position:");
                    int pos= scan.nextInt();;
                    System.out.print("Enter the data:");
                    int val= scan.nextInt();
                    list.insertDataAtSpecificIndex(pos,val);
                    break;
                case 4:
                    System.out.println("Delete at position");
                    System.out.print("Enter the position:");
                    int Pos= scan.nextInt();
                    list.deleteAtPosition(Pos);
                    break;
                case 5:
                    System.out.println("Reversed list");
                    list.reverse();
                    break;
                case 6:
                    System.out.println("Searching");
                    System.out.print("Enter data:");
                    int dat= scan.nextInt();
                    System.out.println(list.search(dat));
                    break;
                default:
                    System.out.println("Invalid option");
                    break;




            }
        }


    }
}

