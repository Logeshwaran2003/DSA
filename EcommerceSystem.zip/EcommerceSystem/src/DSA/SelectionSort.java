package DSA;

import java.util.Arrays;

public class SelectionSort {

    public void sort(int[] arr){
        for (int pos=0;pos< arr.length;pos++){
            int min=arr[pos];//fix the first element as min value
            int minIndex=pos;//fix the min value index
            for (int i=pos+1;i< arr.length;i++){
                if (arr[i]<min){
                    min=arr[i];
                    minIndex=i;
                }
            }
            //Swapping the first and min element
            int temp=arr[pos];
            arr[pos]=arr[minIndex];
            arr[minIndex]=temp;


        }
    }

    public static void main(String args[]){
        SelectionSort sorting=new SelectionSort();
        int arr[]={23,1,10,3,34,2};
        sorting.sort(arr);
        System.out.println(Arrays.toString(arr));


    }
}
