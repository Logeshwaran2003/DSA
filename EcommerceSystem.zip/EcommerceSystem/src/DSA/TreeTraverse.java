package DSA;

public class TreeTraverse {
    int val;
    TreeTraverse left;
    TreeTraverse right;

    public TreeTraverse(int val){
        this.val=val;
    }


    public static void main(String[] args){
        TreeTraverse root=new TreeTraverse(1);
        root.left=new TreeTraverse(2);
        root.left.left=new TreeTraverse(4);
        root.left.right=new TreeTraverse(5);
        root.left.left.left=new TreeTraverse(6);
        root.right=new TreeTraverse(3);
        root.right.right=new TreeTraverse(7);
        System.out.println("Inorder:");
        Inorder(root);
        System.out.println();
        System.out.println("Preorder:");
        Preorder(root);
        System.out.println();
        System.out.println("Postorder:");
        Postorder(root);
    }
    public static void Inorder(TreeTraverse root){
        if (root!=null) {
            Inorder(root.left);
            System.out.print(root.val + " ");
            Inorder(root.right);
        }

    }

    public static void Preorder(TreeTraverse root){

        if (root!=null){
            System.out.print(root.val+" ");
            Preorder(root.left);
            Preorder(root.right);
        }
    }


    public static void Postorder(TreeTraverse root){

        if (root!=null){
            Postorder(root.left);
            Postorder(root.right);
            System.out.print(root.val+" ");
        }
    }


}
