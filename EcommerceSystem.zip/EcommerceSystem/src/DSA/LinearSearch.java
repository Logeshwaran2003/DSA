package DSA;

/*
Searching is used to find the element which is present or not
There are linear and binary search
Linear search:
It is search one by one in an array.If the element found means it return the index else return -1

Complexity:
if element found in arr[0]-O(1)
else-O(n)
we perform:1.Find an int in an array
           2.Find a character in an array
           3.Find an int or char in a 2D array
 */

import java.util.Arrays;

public class LinearSearch {

    public int findInt(int arr[],int target){
        for (int i=0;i<arr.length;i++){
            if (arr[i]==target){
                return i;
            }
        }
        return -1;
    }

    public int findChar(String str,char c){
        for (int i=0;i<str.length();i++){
            if (str.charAt(i)==c){
                return i;
            }
        }
        return -1;
    }

    public int[] findInt2D(int arr[][],int target){
        for (int i=0;i<arr.length;i++){
            for (int j=0;j<arr[i].length;j++){
                if (arr[i][j]==target){
                    return new int[] {i,j};
                }
            }
        }
        return new int[]{-1,-1};
    }

    public static void main(String args[]){
        LinearSearch LS=new LinearSearch();
        int arr[]={1,2,3,4,5};
        int target=7;
        System.out.println(LS.findInt(arr,target));
        String str="think";
        char c='i';
        System.out.println(LS.findChar(str,c));
        int ar[][]={{1,2,3},{4,5,6}};
        int targ=5;
        int result[]=LS.findInt2D(ar,targ);
        System.out.println(Arrays.toString(result));



    }
}


