package DSA;

/* Stack-LIFO
example:Bunch of plates,history
push-add the element
pop-remove the element recently added
peek-show the top element
*/
import java.util.*;
public class Stack
{
    int a[];
    int tos;

    public Stack(){
        this.a=new int[10];
        this.tos=-1;
    }

    public void push(int data){
        if (tos==a.length-1){
            System.out.println("Stack is full");
            return;
        }
        a[++tos]=data;
        System.out.println("Pushed: "+data);
    }

    public void pop(){
        if (tos==-1){
            System.out.println("Stack is empty");
            return;
        }
        System.out.println("Popped: "+a[tos--]);
    }

    public void display(){
        for (int i=0;i<=tos;i++){
            System.out.print(a[i]+" ");

        }
        System.out.println();
    }

    public void peek(){
        System.out.println(a[tos]);
    }
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        Stack s1=new Stack();
        while(true){
            System.out.println("1.Push");
            System.out.println("2.Pop");
            System.out.println("3.Display");
            System.out.println("4.Peek");
            System.out.print("Choose the option:");
            int choose=scan.nextInt();
            switch(choose){
                case 1:
                    System.out.println("Pushing element");
                    System.out.print("Enter the data:");
                    int data=scan.nextInt();
                    s1.push(data);
                    break;
                case 2:
                    System.out.println("Popping element");
                    s1.pop();
                    break;
                case 3:
                    System.out.println("Displaying");
                    s1.display();
                    break;
                case 4:
                    System.out.println("Peek");
                    s1.peek();
                    break;
                default:
                    System.out.println("Invalid option");
            }



        }}

}

