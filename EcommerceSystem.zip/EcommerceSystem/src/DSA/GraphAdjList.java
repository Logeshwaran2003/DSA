package DSA;

import java.util.ArrayList;

public class GraphAdjList {
    ArrayList<ArrayList<Integer>> adjlist=new ArrayList<>();

    public GraphAdjList(int size){
    for (int i=0;i<size;i++){
        adjlist.add(new ArrayList<Integer>());
    }
    }

    public void addEdge(int v,int e){
        adjlist.get(v).add(e);
        adjlist.get(e).add(v);
    }

    public void displayList(){
        for (int i=0;i<adjlist.size();i++){//i is vertex number
            System.out.println("Vertex number is "+i);
            for (int j=0;j<adjlist.get(i).size();j++){
                System.out.print(adjlist.get(i).get(j)+" ");

            }
            System.out.println();

        }
    }

    public static void main(String args[]){
        GraphAdjList g=new GraphAdjList(5);
        g.addEdge(0,1);
        g.addEdge(0,4);
        g.addEdge(1,2);
        g.addEdge(1,4);
        g.addEdge(2,3);
        g.addEdge(3,4);
        g.displayList();


    }

}
