package DSA;

/*
Tree is non-linear DS - Data is not stored sequentially called non-linear
Root
Node
Edge

Tree is a collection of nodes and edges to form a hierarchical DS
Application-File system
            Search trees(left is small and right is large)
            XML parser

child - direct successor
parent - direct predecessor
root - a node with no parent
sibling - a child have same parents
leaf node - no child node - external node
non leaf node - node with child - internal node
N Node,N-1 edges
Path-sequence of consecutive edges between two nodes
Ancestor-any predecessor node on path from root to that node(Previous generation)
Descendant - any successor node on a path from that node a leaf node(possible paths)
Sub tree-containing a node of tree and its descendant
Depth - No.of.edges in the path from the root to that node
Height - No.of.edges in longest path from the node to leaf
Degree - No of children under the node


Binary Tree:

height-h

S=a(r^n -1)/n-1 , n=h+1

h=0,2^0=1 node,h==edges
h=1,2^1=2 node ,h==edges

min node=height is h+1 nodes
max node =height is 2^(h+1) -1 nodes

min height = node is n-1
max height = node is log(n+1) -1


Types of Binary tree:

1.Full/proper/strict binary tree:
Binary tree with 0 or 2 childrens
All node except leaf node have two childrens
no of leaf node=no of internal node +1
Total number of nodes n will be always odd
Condition:
min number of nodes in a full binary tree of height is 2h+1
max node =height is 2^(h+1) -1 nodes

max height of full binary tree is n-1/2
min height = node is n-1

2.Complete binary tree:
All level except last node there will completely filled and all nodes are left as possible

Condition:
min number of nodes in complete binary tree of height h is 2^h nodes
height of the complete binary tree is floor(log n)

3.Perfect binary tree:
All levels are compltely filled
all leaf node at same level

4.Degenerate binary tree:
all internal nodes have one child only

5.Balanced binary tree:
Absolute difference between height of left and right subtree for each node is maximum 1

*/

public class BinaryTree {
    Node root;

    class Node{
        int val;
        Node left;
        Node right;

        Node(int val){
            this.val=val;
            left=null;
            right=null;
        }
    }
    public BinaryTree(int data){
        root = new Node(data);

    }

    public void insertAtLeft(Node root,int data){
        Node newNode=new Node(data);
        root.left=newNode;    // root.left=new Node(data) - another method to create
    }

    public void insertAtRight(Node root,int data){
        Node newNode=new Node(data);
        root.right=newNode;
    }

    public static void main(String args[]){

        BinaryTree tree=new BinaryTree(10);
        tree.insertAtLeft(tree.root,9);
        tree.insertAtRight(tree.root,11);
        tree.insertAtLeft(tree.root.left,8);
        tree.insertAtRight(tree.root.left,12);
        tree.insertAtLeft(tree.root.right,7);
        tree.insertAtRight(tree.root.right,13);
    }

}
