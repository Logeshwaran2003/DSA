package DSA;
/*
Graph is a non-linear DS
It contains vertexes and edges ,vertexes are nodes only
Graph is a group of network

Application:
Social media,google map,maze game

Terminologies:
1.Degree of vertex-Number of adjacent vertices
2.Undirected graph-There is no arrow marks between the vertexes is called undirected graph
3.Directed graph-There is arrow mark for the direction
4.Weighted graph-There will be number between the two vertexes
5.Sparse graph-each vertex connect to left and right side vertex
6.Complete graph-each vertex connect to all the vertexes like mesh topology
7.Dense graph -each vertex connect to many vertexes but there is no each vertex connect to all vertexes

Adjacency matrix:
Take count of vertex and make a matrix. For example vertex count=5 means tale 5*5 matrix
Find the connection between the vertexes by iterating the matrix one by one.Like routing algo

Adjacency list:
It similar to matrix but if there is vertex of 1,2,3,4,5. if I choose 1 means it shows what are the vertexes connected in
vertex 1 in list
There is possible to store the number between the vertexes.vertex=[vertex,number,vertex,number] ,number-distance

Choose matrix and list based on the scenario:
if I want find 4 th vertex will be connected to 2 nd vertex or not? means In matrix is easy just check arr[4][2]
But it is take time in list fint 4th vertex and itr a list and find



 */
public class GraphAdjMatrix {
    public static void main(String args[]){
        int arr[][]={{0,1,1,0,0},{1,0,0,0,1},{0,1,1,1,1},{0,0,0,0,1},{1,1,1,1,1}};
    }
}
