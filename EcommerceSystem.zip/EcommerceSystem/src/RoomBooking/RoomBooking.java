package RoomBooking;

import java.util.*;

interface ListDetails{
    public String ListDetails();
}

class user implements ListDetails{
    private int user_id;
    private String username;
    private String password;

    public user(int user_id,String username,String password){
        this.user_id=user_id;
        this.username=username;
        this.password=password;
    }

    public int getUser_id(){
        return user_id;
    }
    public void setUser_id(int user_id){
        this.user_id=user_id;
    }

    public String getUsername(){
        return username;
    }

    public void setUsername(String username){
        this.username=username;
    }

    public String getPassword(){
        return password;
    }

    public void setPassword(String password){
        this.password=password;
    }

    public static boolean Login(ArrayList<user> users,String username,String password){
        for (user i:users){
            if (i.getUsername().equals(username) && i.getPassword().equals(password)){
                System.out.println("Login successful");
                System.out.println("Welcome "+i.getUsername());
                return true;
            }
            System.out.println("Invalid username and password");
        }
        return false;
    }

    public String ListDetails(){
        return "user_id:"+user_id+"\nusername:"+username;
    }
}

class hotel implements ListDetails{
    private int hotel_id;
    private String hotel_name;
    private ArrayList<room> rooms;

    public hotel(int hotel_id,String hotel_name){
        this.hotel_id=hotel_id;
        this.hotel_name=hotel_name;
        this.rooms=new ArrayList<>();
    }

    public int getHotel_id(){
        return hotel_id;
    }
    public String getHotel_name(){
        return hotel_name;
    }
    public ArrayList<room> getRooms(){
        return rooms;
    }
    public void addRooms(room room){
        rooms.add(room);
    }

    public String ListDetails(){

        return "hotel_id:"+hotel_id+"\nhotel_name:"+hotel_name;
    }
}

class room implements ListDetails{
    private int room_id;
    private int room_no;
    private String room_type;
    private boolean room_status;
    private double price;

    public room(int room_id,int room_no,String room_type,boolean room_status,double price){
        this.room_id=room_id;
        this.room_no=room_no;
        this.room_type=room_type;
        this.room_status=room_status;
        this.price=price;
    }

    public int getRoom_id(){
        return room_id;
    }
    public int getRoom_no(){
        return room_no;
    }

    public String getRoom_type(){
        return room_type;
    }

    public boolean getRoom_Status(){
        return room_status;
    }

    public void setRoom_status(boolean room_status){
        this.room_status=room_status;
    }

    public double getPrice(){
        return price;
    }

    public String ListDetails(){
        return "room_id:"+room_id+"\nroom_no:"+room_no+"\nroom_type:"+room_type+"\nroom_price:"+price;
    }

}

class book implements ListDetails{
    private int book_id;
    private hotel hotel;
    private user user;
    private room room;
    private Date book_date;
    private int book_days;
    private double totalPrice;
    static int tos=-1;


    public book(int book_id,user user,hotel hotel,room room,Date book_date,int book_days,double totalPrice){
        this.book_id=book_id;
        this.user=user;
        this.hotel=hotel;
        this.room=room;
        this.book_date=book_date;
        this.book_days=book_days;
        this.totalPrice=totalPrice;


    }

    public int getBook_id(){
        return book_id;
    }

    public user getUser(){
        return user;
    }

    public hotel getHotel(){
        return hotel;
    }

    public room getRoom(){
        return room;
    }

    public Date getBook_date(){
        return book_date;
    }

    public int getBook_days(){
        return book_days;
    }

    public double getTotalPrice(){
        return totalPrice;
    }

    public static void push(ArrayList<book> booking,book book){
        booking.add(++tos,book);

    }

    public static book pop(ArrayList<book> booking){
        return booking.remove(tos--);
    }

    public String ListDetails(){
        return "book_id:"+book_id+"\nuser_id:"+user.getUser_id()+"\nhotel_id:"+hotel.getHotel_id()+"\nroom_id:"+room.getRoom_id()+"\nbook_date:"+book_date+"\nbook_days:"+book_days+"\nTotalAmount:"+totalPrice;
    }
}
public class RoomBooking {
    public static void main(String args[]){
        Scanner scan=new Scanner(System.in);
        ArrayList<user> users=new ArrayList<user>();
        ArrayList<hotel> hotels=new ArrayList<>();
        ArrayList<room> rooms=new ArrayList<>();
        ArrayList<book> bookings=new ArrayList<>();
        ArrayList<book> history=new ArrayList<>();
        user user1=new user(1,"Logesh","Logesh@123");
        hotel hotel1=new hotel(1,"5 star");
        room room1=new room(1,101,"4BHK",true,2500.00);
        room room2=new room(2,102,"2BHK",true,1500.00);
        users.add(user1);
        hotels.add(hotel1);
        rooms.add(room1);
        rooms.add(room2);
        hotel1.addRooms(room1);
        hotel1.addRooms(room2);
        boolean loggedIn=false;
        while (true){
            System.out.println("1.Login");
            System.out.println("2.Exit");
            System.out.print("Choose the option:");
            int choose= scan.nextInt();
            switch (choose){
                case 1:
                    System.out.print("Enter the username:");
                    scan.nextLine();
                    String username=scan.nextLine();
                    System.out.print("Enter the password:");
                    String password=scan.nextLine();
                    loggedIn=user.Login(users,username,password);
                    while (loggedIn){
                        user selectedUser=null;
                        for (user i:users){
                            if (i.getUsername().equals(username)){
                                selectedUser=i;
                            }
                        }
                        System.out.println("1.List the users");
                        System.out.println("2.List the hotels");
                        System.out.println("3.List the rooms");
                        System.out.println("4.Book the room");
                        System.out.println("5.History");
                        System.out.println("6.Logout");
                        System.out.print("Choose the option:");
                        int choice= scan.nextInt();
                        switch(choice){
                            case 1:
                                System.out.println("List of users");
                                for (user i:users){
                                    System.out.println(i.ListDetails());
                                }
                                break;
                            case 2:
                                System.out.println("List of hotels");
                                for (hotel i:hotels){
                                    System.out.println(i.ListDetails());
                                }
                                break;
                            case 3:
                                System.out.println("List of rooms");
                                for (room i:rooms){
                                    System.out.println(i.ListDetails());
                                }
                                break;
                            case 4:
                                System.out.println("Booking");
                                System.out.print("Enter the hotel_id:");
                                int hotel_id= scan.nextInt();
                                hotel selectedHotel=null;
                                for (hotel i:hotels){
                                    if (i.getHotel_id()==hotel_id){
                                        selectedHotel=i;
                                    }
                                }
                                System.out.println("Rooms in hotel");
                                for (room i:selectedHotel.getRooms()){
                                    System.out.println(i.ListDetails());
                                }
                                room selectedRoom=null;
                                System.out.print("Enter the room_id:");
                                int room_id=scan.nextInt();
                                for (room i:rooms){
                                    if (i.getRoom_id()==room_id){
                                        selectedRoom=i;
                                    }
                                }
                                if (selectedRoom.getRoom_Status()==true){
                                    System.out.print("Enter the number of days:");
                                    int days= scan.nextInt();
                                    double amount=selectedRoom.getPrice()*days;
                                    book book1=new book(bookings.size()+1,selectedUser,selectedHotel,selectedRoom,new Date(),days,amount);
                                    bookings.add(book1);
                                    System.out.println("You booked the room "+selectedRoom.getRoom_no()+" Successfully");
                                    System.out.println("You paid the amount of Rs "+amount+" for "+days+"days");
                                    selectedRoom.setRoom_status(false);
                                    book.push(history,book1);
                                    break;
                                }
                                else{
                                    System.out.println("You selected room was not available");
                                    break;
                                }
                            case 5:
                                System.out.println("History");
                                for (int i=0;i<history.size()+1;i++){
                                    System.out.println(book.pop(history).ListDetails());
                                }
                                break;
                            case 6:
                                System.out.println("Logging out.................");
                                loggedIn=false;
                                break;
                            default:
                                System.out.println("Invalid option");
                                break;

                        }

                    }
                    break;
                case 2:
                    System.out.println("Exiting................");
                    System.exit(0);

            }
        }

    }
}
