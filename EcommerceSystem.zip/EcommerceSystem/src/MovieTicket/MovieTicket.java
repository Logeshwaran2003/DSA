package MovieTicket;

import java.util.*;

interface viewDetails{
    public String ListDetails();
}
class User implements viewDetails{
    private int user_id;
    private String user_name;
    private String password;

    public User(int user_id,String user_name,String password){
        this.user_id=user_id;
        this.user_name=user_name;
        this.password=password;
    }

    public int getUser_id(){
        return user_id;
    }

    public void setUser_id(int user_id){
        this.user_id=user_id;
    }
    public String getUser_name(){
            return user_name;
    }

    public void setUser_name(String user_name){
    this.user_name=user_name;
    }

    public String getPassword(){
        return password;
    }

    public void setPassword(String password){
        this.password=password;
    }

    public static boolean Login(ArrayList<User> users,String username,String password){
        for (User i:users){
            if (i.getUser_name().equals(username) && i.getPassword().equals(password)){
                System.out.println("Login Successful");
                System.out.println("Welcome "+i.getUser_name());
                return true;
            }
        }
        System.out.println("Invalid username and password");
        return false;


    }

    public String ListDetails(){
        return "User_id: "+user_id+"\nUsername: "+user_name;

    }
}

class Movie implements viewDetails{
    private int movie_id;
    private String movie_name;
    private double movie_price;

    public Movie(int movie_id,String movie_name,double movie_price){
        this.movie_id=movie_id;
        this.movie_name=movie_name;
        this.movie_price=movie_price;
    }

    public int getMovie_id(){
        return movie_id;
    }

    public String getMovie_name(){
        return movie_name;
    }

    public double getMovie_price(){
        return movie_price;
    }

    public String ListDetails(){
        return "Movie_id: "+movie_id+"\nMovie_name: "+movie_name+"\nMovie_price: "+movie_price;
    }

}

class Theater implements viewDetails{
    private int theater_id;
    private String theater_name;
    private ArrayList<Movie> movies;

    public Theater(int theater_id,String theater_name){
        this.theater_id=theater_id;
        this.theater_name=theater_name;
        this.movies=new ArrayList<>();
    }

    public int getTheater_id(){
            return theater_id; }
    public String getTheater_name(){
        return theater_name;
    }
    public void addMovies(Movie movie){
        movies.add(movie);
    }

    public ArrayList<Movie> getMovies(){
        return movies;
    }
    ;
    public String ListDetails(){
        return "Theater_id: "+theater_id+"\nTheater_name: "+theater_name;
    }

}

class Book implements viewDetails{
    private int book_id;

    private User user;
    private Theater theater;
    private Movie movie;
    private ArrayList<Book> bookings;
    private int movie_ticket;

    private double total_amount;

    public Book(int book_id,User user,Theater theater,Movie movie,int movie_ticket,double total_amount){
        this.book_id=book_id;
        this.user=user;
        this.theater=theater;
        this.movie=movie;
        this.bookings=new ArrayList<Book>();
        this.movie_ticket=movie_ticket;
        this.total_amount=total_amount;
    }

    public int getBook_id(){
        return book_id;
    }

    public User getUser(){
        return user;
    }

    public Theater getTheater(){
        return theater;
    }

    public Movie getMovie(){
        return movie;
    }

    public ArrayList<Book> getBookings(){
        return bookings;
    }

    public int getMovie_ticket(){
        return movie_ticket;
    }

    public double getTotal_amount() {
        return total_amount;
    }

    public String ListDetails(){
        return "book_id: "+book_id+"\nuser_name: "+getUser().getUser_name()+"\nMovieTicket.Theater name: "+getTheater().getTheater_name()+"\nMovieTicket.Movie name: "+getMovie().getMovie_name() +"\nTicket Count: "+movie_ticket+"\nTotal_amount: "+total_amount;
    }
}



public class MovieTicket {
    public static void main(String[] args){
        User user1=new User(1,"Logeshwaran","Logesh@123");
        User user2=new User(2,"Sasikumar","Sasi@123");
        ArrayList<User> users=new ArrayList<User>();
        users.add(user1);
        users.add(user2);
        ArrayList<Theater> theaters=new ArrayList<Theater>();
        Theater theater1=new Theater(1,"Sathyam");
        Theater theater2=new Theater(2,"INOX");
        theaters.add(theater1);
        theaters.add(theater2);
        Movie movie1=new Movie(1,"Leo",250.0);
        Movie movie2=new Movie(2,"Kaithi",200.0);
        ArrayList<Movie> movies=new ArrayList<Movie>();
        movies.add(movie1);
        movies.add(movie2);
        theater1.addMovies(movie1);
        theater1.addMovies(movie2);
        theater2.addMovies(movie1);
        ArrayList<Book> bookings=new ArrayList<Book>();
        Stack<Book> history=new Stack<Book>();
        boolean loggedIn=false;
        Scanner scan=new Scanner(System.in);
        while(true){
            System.out.println("1.Login");
            System.out.println("2.Exit");
            System.out.print("Choose the option:");
            int choose= scan.nextInt();
            switch (choose){
                case 1:
                    System.out.print("Enter the username:");
                    scan.nextLine();
                    String username= scan.nextLine();
                    System.out.print("Enter the password:");
                    String password=scan.nextLine();
                    loggedIn=User.Login(users,username,password);
                    while (loggedIn){
                        System.out.println("1.List the users");
                        System.out.println("2.List the movies");
                        System.out.println("3.List the theatres");
                        System.out.println("4.Choose the movie");
                        System.out.println("5.Choose the theatre");
                        System.out.println("6.History");
                        System.out.println("7.Logout");
                        System.out.print("Choose the option:");
                        int choice=scan.nextInt();
                        switch (choice){
                            case 1:
                                for (User i:users){
                                    System.out.println(i.ListDetails());
                                }
                                break;
                            case 2:
                                for (Movie i:movies){
                                    System.out.println(i.ListDetails());
                                }
                                break;
                            case 3:
                                for (Theater i:theaters){
                                    System.out.println(i.ListDetails());
                                }
                                break;
                            case 4:
                                for (Movie i:movies){
                                    System.out.println(i.ListDetails());
                                }
                                System.out.print("Choose the movie_id:");
                                int movie_id= scan.nextInt();
                                Movie selectedMovie=null;
                                for (Movie i:movies){
                                    if (i.getMovie_id()==movie_id){
                                        selectedMovie=i;
                                    }
                                }
                                for (Theater i:theaters){
                                    if (i.getMovies().contains(selectedMovie)){
                                        System.out.println(i.ListDetails());
                                    }

                                }

                                Theater selectedTheater=null;
                                System.out.print("Choose the theater_id:");
                                int theater_id= scan.nextInt();
                                for (Theater i:theaters){
                                    if (i.getTheater_id()==theater_id){
                                        selectedTheater=i;
                                        System.out.println("You have selected the theatre "+selectedTheater.getTheater_name()+" for the movie "+selectedMovie.getMovie_name());
                                        System.out.println("Please make an order.....");
                                    }

                                }

                                System.out.print("MovieTicket.Book the movie(Yes/No): ");
                                scan.nextLine();
                                String bookChoice= scan.nextLine();
                                switch (bookChoice){
                                    case "Yes":
                                        System.out.print("Enter the user_id: ");
                                        int user_id=scan.nextInt();
                                        User selectedUser=null;
                                        for (User i:users){
                                            if (i.getUser_id()==user_id){
                                                selectedUser=i;

                                            }
                                        }
                                        System.out.print("Enter the ticket count: ");
                                        int Ticket= scan.nextInt();
                                        double totalAmount=selectedMovie.getMovie_price()*Ticket;
                                        bookings.add(new Book(bookings.size()+1,selectedUser,selectedTheater,selectedMovie,Ticket,totalAmount));
                                        System.out.println("Your order confirmed...");
                                        for (Book i:bookings){
                                            System.out.println(i.ListDetails());
                                        }
                                        System.out.println("You paid amount of Rs."+totalAmount+" for this order");
                                        System.out.println("Thank you "+selectedUser.getUser_name());
                                        history.push(new Book(bookings.size(),selectedUser,selectedTheater,selectedMovie,Ticket,totalAmount));
                                        break;
                                    case "No":
                                        System.out.println("ASAP make the order confirm...");
                                        break;

                                }

                                break;
                            case 5:
                                for (Theater i:theaters){
                                    System.out.println(i.ListDetails());
                                }

                                System.out.print("Select the theatre_id:");
                                int theater_Id=scan.nextInt();
                                Theater selectedtheater=null;
                                for (Theater i:theaters){
                                    if (i.getTheater_id()==theater_Id){
                                        selectedtheater=i;
                                        for (Movie j:selectedtheater.getMovies()){
                                            System.out.println(j.ListDetails());
                                        }
                                    }
                                }

                                Movie selectedmovie=null;
                                System.out.print("Enter the movie_id:");
                                int movie_Id= scan.nextInt();
                                for (Movie i:movies){
                                    if (i.getMovie_id()==movie_Id){
                                        selectedmovie=i;
                                    }
                                }
                                System.out.println("You have selected the "+selectedtheater.getTheater_name()+" for the movie "+selectedmovie.getMovie_name());
                                System.out.println("Please make an order.....");
                                System.out.print("MovieTicket.Book the movie(Yes/No): ");
                                scan.nextLine();
                                String bookchoice= scan.nextLine();
                                switch (bookchoice) {
                                    case "Yes":
                                        System.out.print("Enter the user_id: ");
                                        int user_id = scan.nextInt();
                                        User selectedUser = null;
                                        for (User i : users) {
                                            if (i.getUser_id() == user_id) {
                                                selectedUser = i;

                                            }
                                        }
                                        System.out.print("Enter the ticket count: ");
                                        int Ticket = scan.nextInt();
                                        double totalAmount = selectedmovie.getMovie_price() * Ticket;
                                        bookings.add(new Book(bookings.size() + 1, selectedUser, selectedtheater, selectedmovie, Ticket, totalAmount));
                                        System.out.println("Your order confirmed...");
                                        for (Book i : bookings) {
                                            System.out.println(i.ListDetails());
                                        }
                                        System.out.println("You paid amount of Rs." + totalAmount + " for this order");
                                        System.out.println("Thank you " + selectedUser.getUser_name());
                                        history.push(new Book(bookings.size() , selectedUser, selectedtheater, selectedmovie, Ticket, totalAmount));
                                        break;
                                    case "No":
                                        System.out.println("ASAP make the order confirm...");
                                        break;


                                }
                                break;
                            case 6:
                                System.out.println("History");
                                for (int i=0;i<=history.size();i++){
                                System.out.println(history.pop().ListDetails());
                                    }
                                break;
                            case 7:
                                System.out.println("Logging out..........");
                                loggedIn=false;
                                break;
                            default:
                                System.out.println("Invalid option...");
                                break;


                        }


                    }
                    break;
                case 2:
                    System.out.println("Exiting....................");
                    System.exit(0);


            }


        }

    }
}
